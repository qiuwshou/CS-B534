package edu.iu.mean;

public class MeanConstants {
	  public static final String VECTOR_SIZE =
	    "vector_size";
	}