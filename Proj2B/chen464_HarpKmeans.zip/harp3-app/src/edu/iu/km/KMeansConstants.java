package edu.iu.km;

/*
 * Define some constants you might use
 */
public class KMeansConstants { 
	
}